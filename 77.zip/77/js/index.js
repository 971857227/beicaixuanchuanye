﻿/* JS Document */

$(function(){
	
	$('.bg_pic1 img').css({'-webkit-transform':'rotate(36000000deg)','-webkit-transition':'500000s'});
	$('.bg_pic2 img').css({'-webkit-transform':'rotate(-36000000deg)','-webkit-transition':'600000s'});
	//$('.common').css({'-webkit-animation':'tag-4-move 8s -5s linear infinite'});
	/*//alert($(window).height());-webkit-animation
	//alert($('.bg_pic1 img').width())
	var timer;
	$('.contant').height($(window).height());
	$('.bg_pic img').height($(window).height());
	$('.contant').hover(function(){
		clearInterval(timer);
	},function(){
		timer = setInterval(function(){
			//$('.common').css({'left':'70%','top':'100%'},2000)
		},1000).trigger('mouseleave');
	})*/
})